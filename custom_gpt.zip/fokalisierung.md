# Fokalisierung 

In diesem Dokument finden sich Beispiele zu den drei Arten der Fokalisierung nach Genette: interne Fokalisierung, externe Fokalisierung und Nullfokalisierung. 

## Beispiele interne Fokalisierung 
interne Fokalisierung: Die Handlung wird stark aus dem Blickwinkel einer einzelnen Figur heraus erzählt, wobei Zusammenhänge, von denen diese Figur nichts weiß, auch nicht erzählt werden. Wichtige Merkmale ist die Innenschau in Gefühle, Gedanken und subjektiven Erleben der Figut. 

### Ludwig Tieck - "Der blonde Eckbert"
Ich wußte nicht, was ich aus mir selber machen sollte, der Hund sprang mich unaufhörlich an, der Sonnenschein breitete sich munter über die Felder aus, die grünen Birken funkelten: ich hatte die Empfindung, als wenn ich etwas sehr Eiliges zu tun hätte, ich griff also den kleinen Hund, band ihn in der Stube fest, und nahm dann den Käfig mit dem Vogel unter den Arm. Der Hund krümmte sich und winselte über diese ungewohnte Behandlung, er sah mich mit bittenden Augen an, aber ich fürchtete mich, ihn mit mir zu nehmen. Noch nahm ich eins von den Gefäßen, das mit Edelsteinen angefüllt war, und steckte es zu mir, die übrigen ließ ich stehn.

### Johann Wolfgang von Goethe - "Die Leiden des jungen Werther"
Wie ich mich unter dem Gespäche in den schwarzen Augen weidete – wie die lebendigen Lippen und die frischen, muntern Wangen meine ganze Seele anzogen – wie ich, in den herrlichen Sinn ihrer Rede ganz versunken, oft gar die Worte nicht hörte, mit denen sie sich ausdrückte – davon hast du eine Vorstellung, weil du mich kennst. Kurz, ich stieg aus dem Wagen wie ein Träumender, als wir vor dem Lusthause stille hielten, und war so in Träumen rings in der dämmernden Welt verloren, daß ich auf die Musik kaum achtete, die uns von dem erleuchteten Saal herunter entgegenschallte.

### Arthur Schnitzler - "Leutnant Gustl"
Wie lang' wird denn das noch dauern? Ich muß auf die Uhr schauen... schickt sich wahrscheinlich nicht in einem so ernsten Konzert. Aber wer sieht's denn? Wenn's einer sieht, so paßt er gerade so wenig auf, wie ich, und vor dem brauch' ich mich nicht zu genieren... Erst viertel auf zehn?... Mir kommt vor, ich sitz' schon drei Stunden in dem Konzert. Ich bin's halt nicht gewohnt... Was ist es denn eigentlich? Ich muß das Programm anschauen... Ja, richtig: Oratorium! Ich hab' gemeint: Messe. Solche Sachen gehören doch nur in die Kirche! Die Kirche hat auch das Gute, daß man jeden Augenblick fortgehen kann. – Wenn ich wenigstens einen Ecksitz hätt'! – Also Geduld, Geduld! Auch Oratorien nehmen ein End'! Vielleicht ist es sehr schön, und ich bin nur nicht in der Laune. Woher sollt' mir auch die Laune kommen? Wenn ich denke, daß ich hergekommen bin, um mich zu zerstreuen...

## Beispiele exteren Fokalisierung
externe Fokalisierung: Hier hat der Erzähler keinen Einblick ins Innenleben einer Figur und beschreibt nur ihre Handlungen. Ein Textabschnitt kann dann als „extern fokalisiert“ bezeichnet werden, wenn sie von Figuren handelt, aber keine direkten Informationen über deren Mentalität oder mentalen Zustände aufweist.

### Franz Kafka - "Die Verwandlung"
Die Schwester eilte zur Mutter und hielt ihr die Stirn. Der Vater schien durch die Worte der Schwester auf bestimmtere Gedanken gebracht zu sein, hatte sich aufrecht gesetzt, spielte mit seiner Dienermütze zwischen den Tellern, die noch vom Nachtmahl der Zimmerherren her auf dem Tische lagen, und sah bisweilen auf den stillen Gregor hin.

### Arthur Schnitzler - "Traumnovelle" 
»Und wie oft«, fragte Albertine, vor sich hinsehend und ohne jede Betonung, »bist du nachher noch denselben Weg gegangen?«
»Was ich dir erzählt habe«, erwiderte Fridolin, »ereignete sich zufällig am letzten Tag unseres Aufenthalts in Dänemark. Auch ich weiß nicht, was unter anderen Umständen geworden wäre. Frag' auch du nicht weiter, Albertine.«
Er stand immer noch am Fenster, unbeweglich. Albertine erhob sich, trat auf ihn zu, ihr Auge war feucht und dunkel, leicht gerunzelt die Stirn. »Wir wollen einander solche Dinge künftighin immer gleich erzählen«, sagte sie.
Er nickte stumm.
»Versprich's mir.«
Er zog sie an sich. »Weißt du das nicht?« fragte er; aber seine Stimme klang immer noch hart.

### Johann Wolfgang von Goethe - "Wilhelm Meisters Lehrjahre"
Mariane rief der Alten, die, nach ihrer Gewohnheit noch fleißig, die veränderlichen Materialien der Theatergarderobe zum Gebrauch des nächsten Stückes anzupassen beschäftigt war. Sie gab die Auskunft, daß eben eine Gesellschaft lustiger Gesellen aus dem Italienerkeller nebenan heraustaumle, wo sie bei frischen Austern, die eben angekommen, des Champagners nicht geschont hätten.
»Schade«, sagte Mariane, »daß es uns nicht früher eingefallen ist, wir hätten uns auch was zugute tun sollen.«
»Es ist wohl noch Zeit«, versetzte Wilhelm und reichte der Alten einen Louisdor hin. »Verschafft Sie uns, was wir wünschen, so soll Sie's mit genießen.«
Die Alte war behend, und in kurzer Zeit stand ein artig bestellter Tisch mit einer wohlgeordneten Kollation vor den Liebenden. Die Alte mußte sich dazusetzen; man aß, trank und ließ sich's wohl sein. 


## Beispiele Nullfokalisierung:
Nullfokalisierung: Tritt ein, wenn sich ein Text eines allwissenden Erzählers bedient, der Einblick in die Gedanken und Gefühle jeder seiner Figuren hat und Zusammenhänge beschreibt, von denen die einzelnen Figuren nichts wissen. Erzählerkommentare oder -reflexionen sind markante Beispiele der Nullfokalisierung.

### Franz Kafka - "Die Verwandlung"
Es war kein Traum. Sein Zimmer, ein richtiges, nur etwas zu kleines Menschenzimmer, lag ruhig zwischen den vier wohlbekannten Wänden. Über dem Tisch, auf dem eine auseinandergepackte Musterkollektion von Tuchwaren ausgebreitet war – Samsa war Reisender – hing das Bild, das er vor kurzem aus einer illustrierten Zeitschrift ausgeschnitten und in einem hübschen, vergoldeten Rahmen untergebracht hatte. Es stellte eine Dame dar, die mit einem Pelzhut und einer Pelzboa versehen, aufrecht dasaß und einen schweren Pelzmuff, in dem ihr ganzer Unterarm verschwunden war, dem Beschauer entgegenhob.

### Thomas Mann - "Buddenbrooks":
Im Buddenbrook-Hause hatte sich vieles verändert. Es war längst nicht mehr das alte. Der allmähliche Verfall, den die Zeit anrichtet, war auch an ihm nicht spurlos vorübergegangen. In dem einst so prächtigen Wohnzimmer fehlten viele der kostbaren Möbelstücke, die nach und nach verkauft oder vererbt worden waren. Die Wände, die einst mit den besten Tapeten bespannt gewesen waren, zeigten nun Risse und Verfärbungen, und der einst so glänzende Parkettboden war stumpf und abgenutzt.


### Robert Musil - "Der Mann ohne Eigenschaften"
Aber es muß hinzugefügt werden, daß er ihm nicht etwa deshalb gefiel, weil er das bürgerliche Leben liebte; im Gegenteil, es beliebte ihm bloß, seinen Neigungen, die einstmals anders gewesen waren, Schwierigkeiten zu bereiten. Vielleicht ist es gerade der Spießbürger, der den Beginn eines ungeheuren neuen, kollektiven, ameisenhaften Heldentums vorausahnt? Man wird es rationalisiertes Heldentum nennen und sehr schön finden. Wer kann das heute schon wissen? Solcher unbeantworteter Fragen von größter Wichtigkeit gab es aber damals hunderte. Sie lagen in der Luft, sie brannten unter den Füßen.

﻿# **Grundbegriffe der Erzähltextanalyse – Perspektiven** 

In diesem Dokument werden die zentralen Begriffe für die Analyse der Erzählperspektive nach Gérard Genette beschrieben und erläutert. 

Gérard Genette macht die Analyse von Erzählperspektiven an der Kategorie der Person fest. Welche Unterscheidungen und Spezifikationen dabei macht, wird nun beschrieben: 

## **Person**

Die Kategorie 'Person' beschreibt die Positionierung des Erzählers oder den Beteiligungsgrad relativ zur erzählten Welt (= Diegese). Bei der Analyse der Kategorie ‚Person‘ stellt sich die Frage, in welchem Maß der Erzähler am erzählten Geschehen beteiligt ist. Normalerweise steht im Rahmen des Erzählten wahlweise die erste oder die dritte Person im Vordergrund, und entsprechend lassen sich drei grundsätzlich verschiedene Arten der Beziehung von Erzähler und Figuren unterscheiden: *1) homodiegetischer Erzähler*, *2) heterodiegetischer Erzähler*, *3) autodiegetischer Erzähler*

/1) *homodiegetischer Erzähler* (Der Erzähler ist Teil der Diegese, aber nicht die Hauptfigur) 

Ein "homodiegetischer Erzähler" ist eine Instanz, die Teil der erzählten Welt ist. Genauer gesagt, ist ein homodiegetischer Erzähler eine Figur innerhalb der Geschichte, die von Ereignissen erzählt, an denen sie selbst teilgenommen hat oder die sie aus erster Hand kennt. Hier dominiert die erste Person, wobei das Ich ein erzählendes oder ein erlebendes Ich bzw. Person sein kann. 

Sprachliche oder stilistische Merkmale einer homodiegetischen Perspektive sind: 

- Ich-Erzählung: Der offensichtlichste Marker für einen homodiegetischen Erzähler ist die Verwendung der ersten Person Singular. Wenn der Erzähler „ich“ sagt, deutet dies darauf hin, dass er über seine eigenen Erfahrungen spricht oder Ereignisse beschreibt, an denen er teilgenommen hat oder die er beobachtet hat.
- Persönliche Reflexionen und Gefühle: Ein homodiegetischer Erzähler teilt oft persönliche Gedanken, Gefühle und Reflexionen mit dem Leser. Diese introspektiven Einblicke sind ein klares Zeichen dafür, dass der Erzähler ein aktiver Teilnehmer oder ein direkter Beobachter der Ereignisse ist.
- Begrenztes Wissen: Ein homodiegetischer Erzähler hat typischerweise nur Zugang zu Informationen und Ereignissen, die er selbst erfahren oder beobachtet hat. Dies führt oft zu einer subjektiven Darstellung der Ereignisse, die durch persönliche Wahrnehmungen gefärbt ist. Die Darstellung von Ereignissen und Charakteren ist daher oft begrenzt oder verzerrt durch die Perspektive des Erzählers.
- Verwendung von Dialogen und innerem Monolog: Homodiegetische Erzähler nutzen häufig Dialoge und inneren Monolog, um Ereignisse und ihre eigenen Reaktionen darauf zu vermitteln. Dies verstärkt die Illusion, dass der Erzähler ein lebendiger Teil seiner eigenen Erzählung ist.
- Details und Beschreibungen aus erster Hand: Die Beschreibungen von Orten, Personen und Ereignissen in einer homodiegetischen Erzählung tragen oft die Markierungen persönlicher Erfahrung. Der Erzähler mag besondere Aufmerksamkeit auf Details legen, die für ihn persönlich bedeutsam sind, was die Geschichte mit einer einzigartigen, persönlichen Perspektive färbt.


\2) *heterodiegetischer Erzähler* (Der Erzähler ist kein Teil der erzählten Welt)

Bei heterodiegetische Erzählungen handelt es sich um Erzählungen, in denen der Erzähler nicht zu den Figuren seiner Geschichte gehört und in denen dementsprechend eine dritte Person dominiert. In diesem Fall gibt es keine erlebende Person, sondern nur eine erzählende. Es handelt sich hierbei um eine Erzählsituation, bei der der Erzähler außerhalb der erzählten Welt steht und keine direkte Verbindung zu den Ereignissen in der Geschichte hat. Im Gegensatz zu einem homodiegetischen Erzähler, der Teil der erzählten Geschichte ist (entweder als Protagonist oder als Nebenfigur), ist der heterodiegetische Erzähler ein Außenstehender, der die Geschichte von einem externen Standpunkt aus erzählt. Dieser Erzählertyp bietet eine übergeordnete Sicht auf die Ereignisse und Charaktere, ohne selbst in die Handlung involviert zu sein.

Die heterodiegetische Perspektive ermöglicht eine objektivere Erzählung im Vergleich zur subjektiven Sichtweise eines homodiegetischen Erzählers. Da der Erzähler außerhalb der erzählten Welt steht, kann er Informationen über die Gedanken und Gefühle verschiedener Charaktere bereitstellen, Einblicke in Ereignisse geben, die gleichzeitig an verschiedenen Orten stattfinden, und den Leser mit Hintergrundinformationen versorgen, die den Charakteren möglicherweise nicht bekannt sind.

Sprachliche oder stilistische Merkmale einer homodiegetischen Perspektive sind: 

- Allwissenheit: Oft ist ein heterodiegetischer Erzähler allwissend (omniscient), was bedeutet, dass er Zugang zu den Gedanken, Gefühlen und unbekannten Hintergrundinformationen aller Charaktere hat. Er kann Ereignisse und innere Zustände beschreiben, die für die Charaktere selbst unzugänglich oder unbekannt sind.
- Objektivität: Da der heterodiegetische Erzähler außerhalb der Geschichte steht, kann er eine größere Objektivität in der Erzählung bieten. Er ist nicht durch persönliche Involviertheit oder Bias beschränkt, obwohl die Auswahl dessen, was erzählt wird, und wie es erzählt wird, immer noch eine Form von Subjektivität darstellt.
- Flexibilität in der Perspektive: Heterodiegetische Erzähler haben die Freiheit, zwischen den Perspektiven verschiedener Charaktere zu wechseln, zeitlich vor- und zurückzuspringen und Informationen zu präsentieren, die über die Kenntnisse einzelner Figuren hinausgehen. Sie können die Erzählung also mit einem breiteren Verständnis der Ereignisse und ihrer Bedeutungen anreichern.
- Unpersönliche Erzählstimme: Häufig präsentiert sich der heterodiegetische Erzähler mit einer unpersönlichen Stimme, die im Hintergrund bleibt und die Geschichte ohne direkte Einmischung oder Kommentierung sachlich und neutral erzählt.
- Möglichkeit der Ironie und kritischen Distanz: Durch die Distanz, die der heterodiegetische Erzähler zur Geschichte hat, kann er eine ironische oder kritische Haltung zu den Ereignissen und Charakteren einnehmen, die für die Leserinnen und Leser Erkenntnisse über Themen und Motive der Erzählung vermitteln kann.


\3) *autodiegetischer* Erzähler (Erzähler ist Hauptfigur im Text) 

Der (homodiegetische) Erzähler ist zugleich die Hauptfigur, der Erzähler erzählt gewissermaßen seine eigene Geschichte. Beim autodiegetischen Erzähler handelt es sich somit um eine Sonderform des homodiegetischen Erzählers. 

Sprachliche oder stilistische Merkmale einer autodiegetischen Perspektive sind: 

- Erste Person Singular: Die Verwendung der ersten Person Singular („ich“) ist das auffälligste Merkmal einer autodiegetischen Erzählung. Der Erzähler berichtet aus seiner eigenen Perspektive, was eine intime Verbindung zwischen Erzähler und Leser schafft.
- Subjektive Wahrnehmung und Interpretation: Autodiegetische Erzähler präsentieren die Ereignisse durch den Filter ihrer persönlichen Erfahrungen, Gefühle und Bewertungen. Diese subjektive Färbung beeinflusst die Darstellung der Realität in der Erzählung, wodurch Leser die Geschichte durch die Augen des Erzählers erleben.
- Introspektion und Reflexion: Häufig enthalten autodiegetische Erzählungen ausgedehnte Passagen, in denen der Erzähler über sich selbst, seine Gefühle, Gedanken und Motivationen nachdenkt. Diese Selbstreflexion ermöglicht ein tieferes Verständnis der psychologischen Dimension des Erzählers.
- Authentizität und Glaubwürdigkeit: Durch die Ich-Perspektive kann eine autodiegetische Erzählung einen hohen Grad an Authentizität und persönlicher Glaubwürdigkeit vermitteln, obwohl der Erzähler aufgrund seiner subjektiven Sichtweise auch unzuverlässig sein kann.
- Detaillierte Darstellung von Emotionen und Erfahrungen: Autodiegetische Erzähler bieten oft detaillierte Beschreibungen ihrer inneren emotionalen Zustände und physischen Erfahrungen. Diese Details tragen zur emotionalen Tiefe und zur psychologischen Komplexität der Erzählung bei.
- Sprachliche Besonderheiten: Die Sprache in autodiegetischen Erzählungen kann idiosynkratisch sein und die einzigartige Stimme des Erzählers widerspiegeln. Die Wortwahl, der Rhythmus und der Stil der Sprache können darauf ausgerichtet sein, die Persönlichkeit und die Lebenswelt des Erzählers zum Ausdruck zu bringen.

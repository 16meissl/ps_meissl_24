## interne Fokalisierung 
### Beispiel 1: Autodiegetischer Erzähler mit interner Fokalisierung
Wie lang' wird denn das noch dauern? Ich muß auf die Uhr schauen... schickt sich wahrscheinlich nicht in einem so ernsten Konzert. Aber wer sieht's denn? Wenn's einer sieht, so paßt er gerade so wenig auf, wie ich, und vor dem brauch' ich mich nicht zu genieren... Erst viertel auf zehn?... Mir kommt vor, ich sitz' schon drei Stunden in dem Konzert. Ich bin's halt nicht gewohnt... Was ist es denn eigentlich? Ich muß das Programm anschauen... Ja, richtig: Oratorium! Ich hab' gemeint: Messe. Solche Sachen gehören doch nur in die Kirche! Die Kirche hat auch das Gute, daß man jeden Augenblick fortgehen kann. – Wenn ich wenigstens einen Ecksitz hätt'! – Also Geduld, Geduld! Auch Oratorien nehmen ein End'! Vielleicht ist es sehr schön, und ich bin nur nicht in der Laune. Woher sollt' mir auch die Laune kommen? Wenn ich denke, daß ich hergekommen bin, um mich zu zerstreuen... 

### Beispiel 2: Homodiegetischer Erzähler mit interner Fokalisierung 
Deine Schilderung des widerwärtigen Coppelius ist gräßlich. Erst jetzt vernahm ich, wie Dein guter alter Vater solch entsetzlichen, gewaltsamen Todes starb. Bruder Lothar, dem ich sein Eigentum zustellte, suchte mich zu beruhigen, aber es gelang ihm schlecht. Der fatale Wetterglashändler Giuseppe Coppola verfolgte mich auf Schritt und Tritt und beinahe schäme ich mich, es zu gestehen, daß er selbst meinen gesunden, sonst so ruhigen Schlaf in allerlei wunderlichen Traumgebilden zerstören konnte. Doch bald, schon den andern Tag, hatte sich alles anders in mir gestaltet. Sei mir nur nicht böse, mein Inniggeliebter, wenn Lothar Dir etwa sagen möchte, daß ich trotz Deiner seltsamen Ahnung, Coppelius werde Dir etwas Böses antun, ganz heitern unbefangenen Sinnes bin, wie immer.

### Beispiel 3: Heterodiegetischer Erzhler mit interner Fokalisierung
Der alte Konsul Jean Buddenbrook saß in seinem Büro und betrachtete die Bücher. Die Zahlen sprachen eine klare Sprache: Die Geschäfte gingen schlecht. Er erinnerte sich an die goldenen Zeiten, als der Name Buddenbrook in Lübeck noch etwas zählte. Jetzt sah er das Vermächtnis seiner Familie in Gefahr. Seine Gedanken wanderten zu seinem Sohn Thomas, der einst voller Hoffnung und Tatendrang gewesen war, nun aber von den Lasten der Verantwortung erdrückt wurde. Es schmerzte ihn zu sehen, wie der Glanz der Familie allmählich verblasste.


## externe Fokalisierung 
### Beispiel 1: Autodiegetischer Erzähler mit externer Fokalisierung 
Ich ging durch die engen Gassen des Dorfes und beobachtete die Menschen, die ihrer Arbeit nachgingen. Ein alter Mann zog einen Karren, Kinder spielten auf der Straße und eine Frau hing Wäsche auf. Ich blieb stehen und sah ihnen zu, ohne einen Gedanken an meine eigene Situation zu verschwenden.

### Beispiel 2: Homodiegetischer Erzähler mit externer Fokalisierung 
Der Polizist zieht ein grünes Papierhandtuch 
aus einem Handtuchspender und gibt es mir. 
Was soll ich damit? Den Boden aufwischen? 
Er fasst mit zwei Fingern an seine Nase und 
sieht mich an. Ach so. Nase schnäuzen. Ich 
schnäuze mir die Nase, er lächelt freundlich.

### Beispiel 3: Heterodiegetischer Erzähler miit externer Fokalisierung 
Die Schläge Georgs wurden immer schwächer, immer langsamer; endlich ließ er den Hammer sinken, lüftete die Mütze und trocknete sich den Schweiß ab, der in hellen Tropfen über sein Antlitz rann. Auch Tertschka hielt inne. »Bist du schon müd?« fragte sie, indem sie ihn teilnehmend ansah.
»Weiß Gott, das bin ich«, antwortete er mit tonloser Stimme. »jetzt spür ich erst, wie arg mich das Fieber heruntergebracht hat.«
»Wie hast du auch da heraufkommen können, krank und hinfällig, wie du bist?« fuhr sie fort.
»Was hätt' ich anderes tun sollen? Betteln vielleicht? Das vermag ich nicht. Handwerk hab ich keins gelernt. Vater und Mutter sind mir früh gestorben, und da hab ich im Ort die Gänse hüten müssen und später die Kühe – bis in mein achtzehntes Jahr. Denn ich war immer an Kraft zurück, und kein Bauer hat mich als Knecht nehmen mögen. Aber den Herren von der Assentierung war ich doch recht. ›Im zweiten Glied kann er mitlaufen‹, meinten sie und haben mir den weißen Rock angezogen. Und nun hat man mich krank und elend nach Hause geschickt. Eine Zeitlang wurd' ich von der Gemeinde erhalten; dann hieß es, ich solle gehen und Steine klopfen. Na – und jetzt klopf ich sie«, schloß er mit bitterem Lächeln, während er wieder nach dem Hammer griff.


## Nullfokalisierung 
### Beispiel 1: Autodiegetischer Erzähler mit Nullfokalisierung 
Seit einigen Tagen bewohne ich ein Landhaus, ganz nahe bei London, dasselbe, von dem ich Dir schon mehrmals geschrieben habe, das ich vielleicht kaufen würde. – Meine Unpäßlichkeiten scheinen zurückgeblieben zu sein, ich halte die Luft hier in der Ebene für reiner und gesunder, als dort auf den Bergen. – Meine neuliche Krankheit hat mich aber wieder auf die Zerbrechlichkeit des Lebens aufmerksam gemacht; ich komme in ein Alter, in welchem man sich mehr von der Welt zurückzuziehen wünscht, und einen kleinen lieben Zirkel zu bilden, in dem ein jeder Gedanke und jedes Gefühl bekannt ist. Oh, lieber William, ich hab es mir so schön ausgemalt, was für ein Leben ich führen will, wenn Du nun als gebildeter Mann von Deinen Reisen zurückgekehrt sein wirst, wie mir dann meine letzten Tage in vollem, frohem, unbefangenem Genuß hinfließen sollen: ja ich will von allen Stürmen ausruhn, die so oft den Horizont meines Lebens trübten.

### Beispiel 2: Homodiegetischer Erzähler mit Nullfokalisierung
Mehr kann ich nicht erzählen. 
So haben diese einfachen Bewohner von Nantucket, wenn sie von ihrem Ameisenhügel aus in das Meer hineinstießen, die Welt des Meeres erobert, wie so mancher Alexander. Sie haben den Atlantischen, den Stillen und den Indischen Ozean unter sich aufgeteilt. Mag Amerika Mexiko an Texas angliedern und Kuba samt Kanada schlucken, mögen die Engländer ganz Indien überfluten und ihre Flagge in der Sonne glitzern lassen, zwei Drittel der ganzen Welt gehören den Bewohnern von Nantucket; denn ihnen gehört die See, sie beherrschen sie, wie die Kaiser über Reiche herrschen. Die anderen Seeleute haben nur ein Durchfahrtsrecht.

### Beispiel 3: Heterodiegetischer Erzäher mit Nullfokalisierung 
Die Geschichte Hans Castorps, die wir erzählen wollen, – nicht um seinetwillen (denn der Leser wird einen einfachen, wenn auch ansprechenden jungen Menschen in ihm kennenlernen), sondern um der Geschichte willen, die uns in hohem Grade erzählenswert scheint (wobei zu Hans Castorps Gunsten denn doch erinnert werden sollte, daß es seine Geschichte ist, und daß nicht jedem jede Geschichte passiert): diese Geschichte ist sehr lange her, sie ist sozusagen schon ganz mit historischem Edelrost überzogen und unbedingt in der Zeitform der tiefsten Vergangenheit vorzutragen.